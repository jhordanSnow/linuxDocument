#ifndef CLIPPER_H
#define CLIPPER_H

#include "polygon.h"


#endif
