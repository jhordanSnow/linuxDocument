#include "polygon.h"
#include <stdlib.h>

vector worldVectorToWindow (vector v, Window w) {
  return (vector) {
    (float)(v.x - w.botLeft.x)/(w.topRight.x - w.botLeft.x) * w.resolution.x,
    (float)(v.y - w.botLeft.y)/(w.topRight.y - w.botLeft.y) * w.resolution.y
  };
}

Polygon worldPoligonToWindow (Polygon p, Window w) {
  int i;
  vector* vectorList = (vector*)malloc(sizeof(vector) * p.length);

  for (i = 0; i < p.length; i++) {
    vectorList[i] = worldVectorToWindow(p.points[i], w);
  }
  return (Polygon){
    p.length,
    vectorList
  };
}

void showPolygonLines(Polygon polygon, Window w) {
  int i;
  vector prev = worldVectorToWindow (polygon.points[0], w);
  vector last = worldVectorToWindow (polygon.points[polygon.length - 1], w);
  line(prev.x, prev.y, last.x, last.y);
  for (i = 1; i < polygon.length; i++) {
    vector curr = worldVectorToWindow (polygon.points[i], w);
    line(prev.x, prev.y, curr.x, curr.y);
    prev = curr;
  }
}

#include <stdio.h>

void showPolygonLinesWindow(Polygon polygon) {
  if (polygon.length > 0){
    int i;
    vector prev = polygon.points[0];
    vector last = polygon.points[polygon.length - 1];
    line(prev.x, prev.y, last.x, last.y);
    for (i = 1; i < polygon.length; i++) {
      vector curr = polygon.points[1];
      printf("(%d, %d) => (%d, %d)\n", prev.x, prev.y, curr.x, curr.y);
      line(prev.x, prev.y, curr.x, curr.y);
      prev = curr;
    }
  }
}
