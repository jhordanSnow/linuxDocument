#include <math.h>
#include "main.h"

int H_SIZE = 700;
int V_SIZE = 700;
int CANT_LINES = 2000;

void draw_lines();
extern void line(int x0, int y0, int x1, int y1);

int main(int argc, char** argv){
  glutInit(&argc, argv);
  glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_STENCIL);
  glutInitWindowSize(H_SIZE,V_SIZE);
  glutCreateWindow("Tarea corta: Clipping");
  glClear(GL_COLOR_BUFFER_BIT);
  gluOrtho2D(-0.5, H_SIZE + 0.5, -0.5, V_SIZE + 0.5);
  glutDisplayFunc(draw_lines);
  glutMainLoop();
}


void draw_lines(){
  int lineSet[CANT_LINES][4];
  double timeL1, timeL1Clean, timeL2, timeL2Clean,timeL3, timeL3Clean, timeL4, timeL4Clean, timeL5, timeL5Clean;

  srand(time(NULL));
  for (int i = 0; i < CANT_LINES; i++) {
    for (int j = 0; j < 4; j++) {
      lineSet[i][j] = rand() % H_SIZE;
    }
  }

  setColor(1, 1, 1);
  for (int i = 0; i < CANT_LINES; i++) {
    line(lineSet[i][0], lineSet[i][1], lineSet[i][2], lineSet[i][3]);
    glFlush();
  }
}
